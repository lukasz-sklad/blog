import sys
import os
import json
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]

def build_url(action, **kwargs):
    query = urllib.parse.urlencode(kwargs)
    return f"{base_url}?action={action}&{query}"

def get_token():
    token_url = addon.getSetting('token_url')
    if not token_url:
        xbmcgui.Dialog().ok("Błąd", "Nie podano adresu URL do tokena w ustawieniach wtyczki!")
        return None
    
    try:
        req = urllib.request.Request(token_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req) as response:
            token = response.read().decode('utf-8').strip()
            if not token.startswith("Basic"):
                xbmcgui.Dialog().ok("Błąd", "Pobrany tekst nie wygląda na token. Upewnij się, że link prowadzi do czystego tekstu.")
                return None
            return token
    except Exception as e:
        xbmcgui.Dialog().ok("Błąd", f"Nie udało się pobrać tokena z linku:\n{str(e)}")
        return None

def list_channels():
    xbmcplugin.setPluginCategory(addon_handle, 'Kanały TV')
    xbmcplugin.setContent(addon_handle, 'tvshows')

    addon_dir = addon.getAddonInfo('path')
    channels_file = os.path.join(addon_dir, 'resources', 'data', 'channels.json')

    try:
        with open(channels_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception as e:
        xbmcgui.Dialog().ok("Błąd", f"Nie można załadować listy kanałów: {e}")
        return

    # Pobieramy kanały z pliku
    for ch in data.get('channels', []):
        # Pomijamy stacje radiowe
        if ch.get('is_audio', False):
            continue
            
        title = ch.get('title', 'Nieznany')
        logo = ch.get('channel_logo', '')
        pid_dash = ch.get('pid_dash')
        manifest_url = ch.get('video_src_dash')
        
        # Jeśli kanał nie ma zdefiniowanego pida do DRM, ignorujemy
        if not pid_dash:
            continue
            
        # Dla kanałów typu TVP, które nie mają wprost podanego video_src_dash w pliku
        if not manifest_url:
            slug = title.lower().replace(' ', '').replace('+', 'plus').replace('-', '')
            manifest_url = f"https://lineartv-cdn.t-mobile.pl/bpk-tv/{slug}/default/index.mpd"

        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': logo, 'icon': logo})
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {
            'plot': f"Kliknij, aby włączyć strumieniowanie na żywo.\n\n📺 Kanał: {title}\n📡 Platforma: Magenta TV (T-Mobile)\n🔒 Format: Widevine DRM / DASH",
            'genre': 'Telewizja na żywo',
            'tagline': 'Transmisja na żywo'
        })
        
        url = build_url('play', release_pid=pid_dash, manifest=manifest_url)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)

def play_channel(release_pid, manifest_url):
    token = get_token()
    if not token:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return

    encoded_token = urllib.parse.quote(token)
    
    license_url = f"https://widevine.entitlement.theplatform.eu/wv/web/ModularDrm/getRawWidevineLicense?schema=1.0&form=json&releasePid={release_pid}"
    license_headers = f"Content-Type=application/json&Origin=https://magentatv.pl&Authorization={encoded_token}"

    li = xbmcgui.ListItem(path=manifest_url)
    li.setProperty('inputstream', 'inputstream.adaptive')
    li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
    li.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
    li.setProperty('inputstream.adaptive.license_key', f"{license_url}|{license_headers}|R{{SSM}}|")

    if addon.getSetting('force_720p') == 'true':
        li.setProperty('inputstream.adaptive.stream_selection_type', 'ask-quality')

    xbmcplugin.setResolvedUrl(addon_handle, True, li)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get('action')
    
    if action == 'play':
        play_channel(params.get('release_pid'), params.get('manifest'))
    else:
        list_channels()

if __name__ == '__main__':
    router(sys.argv[2][1:])
